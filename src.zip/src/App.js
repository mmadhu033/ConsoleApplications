import './App.css';
import {Component, react} from 'react';
import Layout from './components/Layout/Layout';
import BurgerBuilder from './containers/BurgerBuilder/BurgerBuilder';

class App extends Component{

  render (){
    return(
      <div>
        <Layout children="Children can be rendered perfectly fine">
          <p>Please add some page inside your Layout</p>
          <BurgerBuilder></BurgerBuilder>
        </Layout>
      </div>
    )
  }
} 



export default App;
