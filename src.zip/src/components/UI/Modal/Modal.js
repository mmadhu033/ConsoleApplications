import React, { Children } from 'react';
import CSSClass from '../Modal/Modal.module.css'
import Backdrop from '../Backdrop/Backdrop';
import Aux from '../../../hoc/_Aux';

const Modal=(props)=>{
    return (
        <Aux>
        <Backdrop show={props.show} showBackdrop={props.showBackdrop}/>
    <div
    className={CSSClass.Modal}
    style={{
        transform:props.show ? 'translateY(0)' : 'translateY(-100vhp)',
        opacity:props.show ? '1' : '0'
    }}
    >
        {props.children}
    </div>
    </Aux>
    )
}

export default Modal;