import React from 'react';
import Classes from '../Button/Button.module.css';

const Button = (props)=>{
    return (
      <button
      onClick={props.clicked}
      className={[Classes.Button, Classes[props.btnType]].join(' ')}
      >
          {props.children}
      </button>
    );
}

export default Button;