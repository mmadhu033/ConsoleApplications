import React from 'react';
import CSSClass from '../Backdrop/Backdrop.module.css';

const Backdrop=(props)=>{
    return(
        props.show ? <div className={CSSClass.Backdrop} onClick={props.showBackdrop}></div> : null
    )
};

export default Backdrop;