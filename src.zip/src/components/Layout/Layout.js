import React from 'react';
import Aux from '../../hoc/_Aux'
import classes from '../Layout/Layout.module.css'

const Layout= (props)=>(
    <Aux>
    <div>
        Toolbar, SideDrawer
    </div>
    <main className={classes.Content}>
        {props.children}
    </main>
    </Aux>
)

export default Layout;