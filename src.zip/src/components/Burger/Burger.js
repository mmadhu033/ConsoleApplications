import React from 'react';
import Classes from '../Burger/Burger.module.css';
import BurgerIngredient from '../BurgerIngredient/BurgerIngredient';

const Burger= (props)=>{
    let transformedIngredients=Object.keys(props.ingredients).map(ingredientName=>{
            return [...Array(props.ingredients[ingredientName])].map((_,i)=>{
            
                return (<BurgerIngredient key={ingredientName+i} type={ingredientName}></BurgerIngredient>)
            });
        }).reduce((accumulator,currentValue)=>{return accumulator.concat(currentValue)},[]);

        if(transformedIngredients.length==0){
            transformedIngredients=<p>Please enter the ingredients</p>
        }
    console.log(transformedIngredients);
    return (
    <div className={Classes.Burger}>
        <BurgerIngredient type='BreadTop'></BurgerIngredient>
       {transformedIngredients}
        <BurgerIngredient type='BreadBottom'></BurgerIngredient>
    </div>
    )
}

export default Burger;