import React from 'react';
import CSSClass from '../BuildControls/BuildControls.module.css';
import BuildControl from './BuildControl/BuildControl';

const BuildControls=(props)=>{
    const Controls=[
        {label:'Salad',type:'Salad'},
        {label:'Veggie',type:'Veggie'},
        {label:'Cheese',type:'Cheese'},
        {label:'Meat',type:'Meat'}
    ];
return(
    <div className={CSSClass.BuildControls}>
        <div>Current Price<strong>:{props.price}</strong></div>
       {Controls.map((CurrentValue,index)=> (
       <BuildControl 
       key={CurrentValue.label} 
       type={CurrentValue.type} 
       label={CurrentValue.label}
       changed={(()=>props.changeHandler(CurrentValue.type))}
       SubtractChanged={()=>props.subtractChangeHandler(CurrentValue.type)}
       disabled={props.ShouldDisable[CurrentValue.type]}
       >
       </BuildControl>))}
       <button disabled={!props.purchaseable} onClick={props.ShowOrderList}>ORDER NOW</button>
    </div>
);
}

export default BuildControls;