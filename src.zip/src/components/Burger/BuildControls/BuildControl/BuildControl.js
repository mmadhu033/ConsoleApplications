import React from 'react';
import CSSClass from '../BuildControl/BuildControl.module.css';

const BuildControl=(props)=>{
  return(
      <div className={CSSClass.BuildControl}>
          <label className={CSSClass.Label}>{props.label}</label>
          <button onClick={props.SubtractChanged} className={CSSClass.Less} disabled={props.disabled}>Less</button>
          <button className={CSSClass.More} onClick={props.changed}>More</button>
      </div>
  );
}

export default BuildControl;