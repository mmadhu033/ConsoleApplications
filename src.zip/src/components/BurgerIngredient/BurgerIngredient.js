import React from 'react';
import PropTypes from 'prop-types';
import classes from '../BurgerIngredient/BurgerIngredient.module.css';

const BurgerIngredient = (props)=> {
    let ingredient =null;
    switch(props.type){
        case 'BreadBottom': ingredient=<div className={classes.BreadBottom}></div> ;
        break;
        case 'BreadTop': ingredient=<div className={classes.BreadTop}><div className={classes.Seeds1}></div>
        <div className={classes.Seeds2}></div>
        </div>;
        break;
        case 'Meat': ingredient=<div className={classes.Meat}></div>;
        break;
        case 'Cheese':ingredient=<div className={classes.Cheese}></div>;
        break;
        case 'Salad': ingredient=<div className={classes.Salad}></div>;
        break;
        case 'Veggie':ingredient=<div className={classes.Veggie}></div>;
        break;
        default : ingredient=null;
        break;
    }
    return ingredient;
}

BurgerIngredient.propTypes={
    type:PropTypes.string.isRequired
}
export default BurgerIngredient;