import React from 'react';
import Button from '../UI/Button/Button';

const OrderSummary=(props)=>{
    const OrderList=Object.keys(props.ingredients).map((Ingredientkeys)=>{
        return(
        <li><span style={{textTransform:'capitalize'}}><bold>{Ingredientkeys}:</bold></span>{ props.ingredients[Ingredientkeys]}</li>
        )}
    );
    console.log(Object.keys(props.ingredients));
    return(
<div>
<ul>
    <p><strong>A Delicious Burger is ready for you to Order !!!</strong></p>
    {OrderList}
    <p><strong>Do you want to checkout now ??</strong></p>
    <Button btnType='Success' clicked={}>CONTINUE</Button>
    <Button btnType='Danger' clicked={props.showBackdrop}>CANCEL</Button>
    
</ul>
</div>
    );
}

export default OrderSummary;