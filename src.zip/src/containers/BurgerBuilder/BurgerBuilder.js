import React, { Component } from 'react';
import BuildControls from '../../components/Burger/BuildControls/BuildControls';
import Burger from '../../components/Burger/Burger';
import Aux from '../../hoc/_Aux';
import Modal from '../../components/UI/Modal/Modal';
import OrderSummary from '../../components/OrderSummary/OrderSummary';

const INGREDIENT_PRICES={
    Salad:1,
    Veggie:2,
    Cheese:3,
    Meat:4
};
const MIN_PRICE=27;
class BurgerBuilder extends Component{
    
    state={
       ingredients:{ Salad:0,
        Veggie:0,
        Cheese:0,
        Meat:0
       },
       totalPrice:MIN_PRICE,
       purchaseable: false,
       ShowOrderList:false
    };
    ShowOrderPopUp =()=>{
        this.setState({ShowOrderList:true});
    }
    updatePurchaseable=()=>{
        const ingredient={...this.state.ingredients};
        const sum=Object.keys(ingredient).map((CurrentValue,index)=>{return ingredient[CurrentValue]}).reduce((accumulator,CurrentValue)=>{
            return accumulator+CurrentValue;
        },0);
        this.setState({purchaseable:sum>0});
    }
    addIngredientHandler=(type)=>{
       const oldCount=this.state.ingredients[type];
       const newcount=oldCount+1;
       const updatedIngredient=this.state.ingredients;
        updatedIngredient[type]=newcount;
        const oldTotalPrice=this.state.totalPrice;
        const updatedTotalPrice=oldTotalPrice+INGREDIENT_PRICES[type];
        this.setState({ingredients:updatedIngredient,totalPrice:updatedTotalPrice});
        this.updatePurchaseable();
    }
    SubtractIngredientHandler=(type)=>{
        const oldCount=this.state.ingredients[type];
        if(oldCount<=0){
            this.setState({ingredients:this.state.ingredients,totalPrice:MIN_PRICE});
            return;
        }
        const newcount=oldCount-1;
        const updatedIngredient=this.state.ingredients;
         updatedIngredient[type]=newcount;
         const oldTotalPrice=this.state.totalPrice;
         const updatedTotalPrice=oldTotalPrice-INGREDIENT_PRICES[type];
         this.setState({ingredients:updatedIngredient,totalPrice:updatedTotalPrice});
        this.updatePurchaseable();
     }

     showBackdrop=()=>{
        this.setState({ShowOrderList:false});;
     }
    //  ShouldDisable=(type)=>{
    //      return 0>=this.state.ingredients[type];
    //  }
    render(){

        const DisabledInfo={
            ...this.state.ingredients
        }
       for(let key in DisabledInfo){
        DisabledInfo[key]=DisabledInfo[key]<=0;
       }
        return(
            <Aux>
                <Modal show={this.state.ShowOrderList} showBackdrop={this.showBackdrop}>
                    <OrderSummary ingredients={this.state.ingredients}></OrderSummary>
                </Modal>
                <div>
                    <Burger ingredients={this.state.ingredients}></Burger>
                    
                </div>
                <div>
                   <BuildControls changeHandler={this.addIngredientHandler} subtractChangeHandler={this.SubtractIngredientHandler} 
                   price={this.state.totalPrice}
                   ShouldDisable={DisabledInfo}
                   purchaseable={this.state.purchaseable}
                   ShowOrderList={this.ShowOrderPopUp}>
                   </BuildControls>
                </div>
            </Aux>
        )
    }
}

export default BurgerBuilder;